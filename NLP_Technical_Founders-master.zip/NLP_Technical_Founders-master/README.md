# NLP_Technical_Founders

Tutorials from the Technical Founders YouTube channel.
